import { usePage } from '@inertiajs/react'; // Untuk mengakses props dari Inertia
import Navbar from '@/Components/Navbar';
import SidebarButton from '@/Components/SidebarButton';
import React from 'react';

const TabelActors = () => {
    const { countries, cast } = usePage().props; // Ambil data negara dari props

    const actors = cast || []; // Gunakan data cast dari server-side props atau array kosong jika tidak ada

    return (
        <div>
            <div className='mb-4'>
                <Navbar />
            </div>
            <div className='ml-4'>
                <SidebarButton />
            </div>
            {/* Input Form */}
            <form>
                <div>
                    <div className="flex flex-wrap items-end gap-6 mb-6 md:grid-cols-2 lg:mx-40 sm:mx-10">
                        <div className="flex gap-6">
                            <div className="grow w-80">
                                <label htmlFor="country" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Country</label>
                                <select
                                    id="country"
                                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                    required
                                >
                                    <option value="">Select Country</option>
                                    {countries.map((country) => (
                                        <option key={country.country_name} value={country.country_name}>
                                            {country.country_name}
                                        </option>
                                    ))}
                                </select>
                            </div>
                            <div className="grow w-96">
                                <label htmlFor="actor_name" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Actor Name</label>
                                <input
                                    type="text"
                                    id="actor_name"
                                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                    placeholder="Input here..."
                                    required
                                />
                            </div>
                            <div className="grow w-48">
                                <label htmlFor="birth" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Birth</label>
                                <input
                                    type="date"
                                    id="birth"
                                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                    required
                                />
                            </div>
                        </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-6 mb-6 md:grid-cols-2 lg:mx-40 sm:mx-10">
                        <div className="flex gap-6 items-end">
                            <div className="grow w-96">
                                <label htmlFor="url_photo" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">URL Photo</label>
                                <input
                                    type="text"
                                    id="url_photo"
                                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                    placeholder="Input URL here..."
                                    required
                                />
                            </div>
                            <button
                                type="submit"
                                className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                            >
                                Submit
                            </button>
                        </div>
                    </div>
                </div>
            </form>

            {/* Data Table */}
            <div className="relative overflow-x-auto shadow-md sm:rounded-lg lg:mx-40 sm:mx-10">
                <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                    <thead className="text-xs text-gray-50 uppercase bg-blue-700 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            {/* Kolom negara, nama aktor, foto, birth, dan aksi */}
                            <th scope="col" className="px-6 py-3">Countries</th>
                            <th scope="col" className="px-6 py-3">Actor Name</th>
                            <th scope="col" className="px-6 py-3">Photos</th>
                            <th scope="col" className="px-6 py-3">Birth</th>
                            <th scope="col" className="px-6 py-3 text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {actors.map((actor) => (
                            <tr key={actor.no} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                <th scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">{actor.country}</th>
                                <th scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">{actor.name}</th>
                                <td className="p-4">
                                    <img src={actor.photo_url} className="w-16 md:w-32 max-w-full max-h-full" alt={actor.name} />
                                </td>
                                {/* Tambahkan kolom Birth */}
                                <td className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                    {actor.birth || 'N/A'} {/* Tampilkan N/A jika tidak ada data birth */}
                                </td>
                                <td className="px-6 py-4 text-right">
                                    <a href="#" className="font-medium text-blue-600 dark:text-blue-500 hover:underline">Edit</a>
                                    <a href="#" className="font-medium text-slate-600 dark:text-white hover:underline"> | </a>
                                    <a href="#" className="font-medium text-red-600 dark:text-red-500 hover:underline">Delete</a>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default TabelActors;
